{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f46f3f2d-ff83-47df-a778-bda9d1bfc99f",
   "metadata": {},
   "outputs": [],
   "source": [
    "import pickle\n",
    "import numpy as np\n",
    "\n",
    "# Load the pre-trained model from a file\n",
    "with open('capstone.pkl', 'rb') as file:\n",
    "    model = pickle.load(file)\n",
    "\n",
    "def get_user_input():\n",
    "    # Define the features expected by the model\n",
    "    feature_names = ['Age', 'Cholesterol', 'Heart Rate', 'Diabetes', 'Family History',\n",
    "       'Smoking', 'Obesity', 'Alcohol Consumption', 'Exercise Hours Per Week',\n",
    "       'Previous Heart Problems', 'Medication Use', 'Stress Level',\n",
    "       'Sedentary Hours Per Day', 'Income', 'BMI', 'Triglycerides',\n",
    "       'Physical Activity Days Per Week', 'Sleep Hours Per Day', 'High_BP ',\n",
    "       'Low_BP', 'Sex_Male', 'Diet_Healthy', 'Diet_Unhealthy',\n",
    "       'Hemisphere_Southern Hemisphere']  # Update with your feature names\n",
    "    \n",
    "    # Initialize an empty list to store the feature values\n",
    "    features = []\n",
    "    \n",
    "    # Prompt the user to enter values for each feature\n",
    "    for feature in feature_names:\n",
    "        while True:\n",
    "            try:\n",
    "                value = float(input(f\"Enter value for {feature}: \"))\n",
    "                features.append(value)\n",
    "                break\n",
    "            except ValueError:\n",
    "                print(\"Invalid input. Please enter a numeric value.\")\n",
    "    \n",
    "    return np.array([features])\n",
    "\n",
    "def main():\n",
    "    # Get user input for the features\n",
    "    user_features = get_user_input()\n",
    "    \n",
    "    # Predict the target using the pre-trained model\n",
    "    prediction = model.predict(user_features)\n",
    "    \n",
    "    # Output the predicted target\n",
    "    print(f\"The predicted target is: {prediction[0]}\")\n",
    "\n",
    "if __name__ == \"__main__\":\n",
    "    main()\n",
    "\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
